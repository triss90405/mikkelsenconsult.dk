# website_boilerplate
Website boilerplate for getting started with new projects.

This project includes stuff like:
* normalize
* gridder
* a full color palette
* usefull mixins
